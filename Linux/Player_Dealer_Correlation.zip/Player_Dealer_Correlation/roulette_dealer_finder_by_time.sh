#! /bin/sh

awk -F" " '{print $1, $2, $5, $6}' ~/Lucky_Duck_Investigations/Roulette_Loss_Investigation/Dealer_Analysis/0310_Dealer_schedule | grep '05:00:00'

